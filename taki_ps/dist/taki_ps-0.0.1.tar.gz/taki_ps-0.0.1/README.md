```shell
flit build

flit install

flit publish
```

```shell
// run from sources
daphne src.taki_ps.asgi:app

// run from bin
daphne taki_ps.asgi:app
```
